angular.module('persistentOLXApp', ['ui.router', 'searchBox'])
    .config(function ($stateProvider, $urlRouterProvider) {

        $urlRouterProvider.otherwise('/home');

        $stateProvider

        // HOME STATES AND NESTED VIEWS ========================================
            .state('home', {
                url: '/home',
                //templateUrl: 'templates/home.html',
                //controller:'productDetailsController'
            })

            // nested list with custom controller
            .state('home.list', {
                url: '/list',
                templateUrl: 'partial-home-list.html',
                controller: function ($scope) {
                    $scope.dogs = ['Bernese', 'Husky', 'Goldendoodle'];
                }
            })

            // nested list with just some random string data
            .state('home.paragraph', {
                url: '/paragraph',
                template: 'I could sure use a drink right now.'
            })

            // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
            .state('productDetails', {
                url: '/productDetails',
                templateUrl: 'templates/productDetails.html',
                controller:'productDetailsController'
            })
            .state('productDetails.productDescription', {
                url: '/productDescription',
                templateUrl: 'templates/productDescription.html',
                controller:'productDescriptionController'
            })
            .state('productDetails.productSpecification', {
                url: '/productSpecification',
                templateUrl: 'templates/productSpecification.html',
                controller:'productSpecificationController'
            })
            .state('sellerInformation', {
                url: '/sellerInformation',
                templateUrl: 'templates/sellerInformation.html',
                controller:'sellerInformationController'
            });;

    });