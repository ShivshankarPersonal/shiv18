angular.module('persistentOLXApp')
    .controller('productDescriptionController', function ($scope) {
        $scope.hi = 'hello'
    });