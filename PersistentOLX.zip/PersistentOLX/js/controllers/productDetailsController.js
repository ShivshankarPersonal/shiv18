angular.module('persistentOLXApp')
    .controller('productDetailsController', function ($scope) {
        $scope.hi = 'hello'
    });