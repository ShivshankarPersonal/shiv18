angular.module('persistentOLXApp')
    .controller('productSpecificationController', function ($scope) {
        $scope.hi = 'hello'
    });