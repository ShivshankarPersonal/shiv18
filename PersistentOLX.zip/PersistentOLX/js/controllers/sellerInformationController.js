angular.module('persistentOLXApp')
    .controller('sellerInformationController', function ($scope) {
        $scope.hi = 'hello'
    });