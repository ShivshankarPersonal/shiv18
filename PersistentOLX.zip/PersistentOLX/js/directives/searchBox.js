angular.module('searchBox', [])
    .directive('searchBox', function (persistentOLXFactory) {
        return {
            restrict: 'E',
            scope: {
                dropDownListUrl: '@'
            },
            templateUrl: 'templates/searchBox.html',
            link: function ($scope, element, attr) {
                persistentOLXFactory.fetchPhonesList().then(function (data, status, headers, config) {
                    console.log(data)
                    $scope.phones = data;
                }, function (data, status) {
                    console.log('Error in fetching phones list'+data+status)
                })
            }
        }
    });