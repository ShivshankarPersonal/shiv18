angular.module('persistentOLXApp')
    .factory('persistentOLXFactory', function ($http, $q) {
        return {
            fetchPhonesList:function(){
                var deferred = $q.defer();
                $http.get('./data/phones.json').success(function (data, status, headers, config) {
                    deferred.resolve(data, status, headers, config);
                }).error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config)
                });
                return deferred.promise;
            }
        }
    });